export interface Usuario {
    nombre: string,
    codigo: string,
    rol: string,
    correo: string,
    celular: string,
    pass: string
}